//
//  File.swift
//  MemeMe
//
//  Created by Deer on 22/10/1441 AH.
//  Copyright © 1441 Udacety. All rights reserved.
//



import UIKit

class MemeCollectionViewCell :UICollectionViewCell{
    
    @IBOutlet weak var memeImageView: UIImageView!
}
