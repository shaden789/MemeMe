//
//  File.swift
//  MemeMe
//
//  Created by Deer on 22/10/1441 AH.
//  Copyright © 1441 Udacety. All rights reserved.
//

import UIKit


struct Meme {
    
    var topText:String
    var bottomText:String
    var orginalImage:UIImage
    var memedImage:UIImage
    
}

